package io.github.libxposed.example

import android.util.Log
import io.github.libxposed.api.XposedModule
import io.github.libxposed.api.XposedModuleInterface.PackageLoadedParam
import java.util.concurrent.atomic.AtomicBoolean

class ModuleMainKt : XposedModule() {
    companion object {
        private const val TAG = "SoftRebootInterceptor"
        private const val TARGET_PACKAGE = "com.android.systemui"
        private const val TARGET_CLASS =
            "com.android.systemui.globalactions.GlobalActionsDialogLite\$RestartAction"
        private val triggered = AtomicBoolean(false)
    }

    override fun onPackageLoaded(param: PackageLoadedParam) {
        if (param.packageName != TARGET_PACKAGE) return

        try {
            val restartClass = Class.forName(TARGET_CLASS, false, param.defaultClassLoader)
            val method = restartClass.getDeclaredMethod("onPress")
            hook(method).intercept { chain ->
                if (!triggered.compareAndSet(false, true)) return@intercept chain.proceed()

                log(Log.WARN, TAG, "Restart pressed; requesting KernelSU soft reboot")
                try {
                    // Use KernelSU's su and absolute ksud path; never rely on PATH in SystemUI.
                    val process = ProcessBuilder(
                        "/system/bin/su", "-c", "/data/adb/ksud soft-reboot"
                    ).redirectErrorStream(true).start()

                    val finished = process.waitFor(3, java.util.concurrent.TimeUnit.SECONDS)
                    if (finished && process.exitValue() != 0) {
                        val output = process.inputStream.bufferedReader().use { it.readText() }
                        log(Log.ERROR, TAG, "ksud failed (${process.exitValue()}): $output")
                        triggered.set(false)
                        chain.proceed()
                    } else {
                        // If command was rejected immediately, let the original Restart action run.
                        // If still running after 3 seconds, assume reboot is underway.
                        if (!finished) log(Log.INFO, TAG, "ksud still running after 3s")
                        null
                    }
                } catch (t: Throwable) {
                    triggered.set(false)
                    log(Log.ERROR, TAG, "Could not invoke KernelSU soft reboot; using normal Restart", t)
                    chain.proceed()
                }
            }
            log(Log.INFO, TAG, "Restart hook installed")
        } catch (t: Throwable) {
            log(Log.ERROR, TAG, "Restart hook installation failed", t)
        }
    }
}
